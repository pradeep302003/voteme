package com.example.signuploginrealtime;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Party extends AppCompatActivity {

    Button Party1, Party2, Party3, Party4;
    FirebaseDatabase database;
    DatabaseReference reference;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_party);

        Party1 = findViewById(R.id.party1_button);
        Party2 = findViewById(R.id.party2_button);
        Party3 = findViewById(R.id.party3_button);
        Party4 = findViewById(R.id.party4_button);

        Party1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                database = FirebaseDatabase.getInstance();
                reference = database.getReference("users");

                String party1 = Party1.getText().toString();
                String party2 = Party2.getText().toString();

                HelperClass helperClass = new HelperClass(party1);
                reference.child(party2).setValue(helperClass);

                Toast.makeText(Party.this, "You are successfully voted to DMK !", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Party.this, FaceReg.class);
                startActivity(intent);
            }
        });

        Party2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                database = FirebaseDatabase.getInstance();
                reference = database.getReference("users");

                String party2 = Party2.getText().toString();
                String party3 = Party3.getText().toString();

                HelperClass helperClass = new HelperClass(party2);
                reference.child(party3).setValue(helperClass);

                Toast.makeText(Party.this, "You are successfully voted to ADMK !", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Party.this, FaceReg.class);
                startActivity(intent);
            }
        });


        Party3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                database = FirebaseDatabase.getInstance();
                reference = database.getReference("users");

                String party3 = Party3.getText().toString();
                String party4 = Party4.getText().toString();

                HelperClass helperClass = new HelperClass(party3);
                reference.child(party4).setValue(helperClass);

                Toast.makeText(Party.this, "You are successfully voted to PMK !", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Party.this, FaceReg.class);
                startActivity(intent);
            }
        });

        Party4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                database = FirebaseDatabase.getInstance();
                reference = database.getReference("users");

                String party4 = Party4.getText().toString();
                String party1 = Party1.getText().toString();

                HelperClass helperClass = new HelperClass(party4);
                reference.child(party1).setValue(helperClass);

                Toast.makeText(Party.this, "You are successfully voted to BJP !", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Party.this, FaceReg.class);
                startActivity(intent);
            }
        });
    }
}